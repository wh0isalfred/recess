# Registration V2 — Apply Instructions

## 1. Base commit

Built against:

```
eaaca44ce73929ec29c1b7581354e8a8e82e473c
```
("fix: restore v1 brand compatibility exports", `origin/main`)

## 2. Created files

```
src/features/registration/RegistrationComplete.tsx
public/brand/v2/onboarding-name.webp
public/brand/v2/onboarding-alias.webp
public/brand/v2/onboarding-whatsapp.webp
```

## 3. Modified files (overwrite existing)

```
src/app/register/NameStep.tsx
src/app/register/alias/AliasStep.tsx
src/app/register/whatsapp/WhatsAppStep.tsx
src/features/registration/RegistrationShell.tsx
src/styles/register.css
docs/SCREEN-STATUS.md
src/app/pass/CheckInScreen.tsx
```

`CheckInScreen.tsx`'s change is a single line — an image path fix — see §6.

## 4. Files to delete

```
src/components/brand/PawnMark.tsx
```

Its asset (`pawn-pink.webp`) and the alias/whatsapp screens' old assets
(`knight-orange.webp`, `rook-pink.webp`) were already moved to
`public/brand/old/` by your own prior asset reorg, so no asset deletion
is needed on your end — they're simply no longer referenced by anything
after this change.

## 5. What changed, functionally

- Screens 03/04/05 (Name/Alias/WhatsApp) fully replaced: real semantic
  headings instead of poster lettering, new V2 illustrations, a new
  shared shell (back chevron, centered V2 wordmark, segmented progress
  bar), inline alias validation against the real backend rule, and a
  new in-place "Registration Complete" transition after successful
  submission (checkmark draws in, holds ~1.6s, then navigates to
  `/pass` — no separate confirmation route).
- `submitRegistration()`, `register_player()`, the anonymous-session
  bootstrap, `draft.ts`, and all three identity guards
  (`register/page.tsx`, `alias/page.tsx`, `whatsapp/page.tsx`) are
  **completely unchanged** — confirmed via `git diff --stat` showing
  zero modifications to the three guard files.

## 6. The `CheckInScreen.tsx` fix — unrelated, found in passing

Your own `public/brand/old/` asset reorg moved `die-pink.webp` out of
`public/brand/` without updating `CheckInScreen.tsx`'s reference,
leaving that image 404ing in production right now, independent of this
slice. Fixed with a one-line path change
(`/brand/die-pink.webp` → `/brand/old/die-pink.webp`). Not a Screen 08
redesign — flagging it here so it isn't mistaken for scope creep.

## 7. Verification results

- **TypeScript**: clean.
- **ESLint**: clean.
- **Next build**: succeeds, same 11-route output as before this slice.
- **Responsive**: verified at 360×740, 390×844, 430×932, 1440×900 — all
  fit exactly, no horizontal or vertical overflow.
- **Keyboard/focus**: Tab order correct (field → CTA), visible 3px amber
  focus rings, Enter-key submission works on all three fields.
- **Reduced motion**: the Registration Complete checkmark's draw-in
  animation is skipped (appears instantly); the ~1.6s hold before
  auto-navigating is unchanged — the pause is for reading the
  confirmation, not decoration.
- **Draft/back-navigation**: verified all three fields correctly
  hydrate from an existing session draft (name, alias, phone, country,
  consent all confirmed), and each step's own `back()` saves the draft
  before navigating.
- **Alias error routing**: verified that a returning `alias_taken`
  error lands back on the alias screen with the previously-entered
  alias intact and the correct message shown (not a generic error on
  the WhatsApp screen).
- **Could not test**: true end-to-end hosted registration (no Supabase
  reachable from this sandbox — established practice for this
  project). Verified everything possible at the logic/UI layer via
  temporary preview routes, created and fully deleted before finishing.

## 8. Consequence worth a decision — Screen 06 is now unreachable

The new in-place Registration Complete transition means
`markPassFresh()` is no longer called from the WhatsApp step (calling
both it and the new transition would show two confirmation screens
back to back, which the brief explicitly said not to do). This makes
`/pass`'s old "Screen 06" celebration (`Confetti`/`Confirmed` in
`PassScreen.tsx`) unreachable — nothing sets the flag it checks for
anymore. Not touched, since Pass is a separate slice — flagged in
`docs/SCREEN-STATUS.md` and here for whenever Pass gets its own V2
pass.

## 9. Visual differences from the supplied references

- A consent checkbox is present on the WhatsApp screen though the
  reference doesn't show one — `register_player()` requires
  `p_consent: true` and rejects a false/missing value, so omitting it
  would either fake consent or break every submission.
- A small "Player: NAME" live preview appears on the alias screen,
  matching the brief's own example ("PLAYER: WH0ISALFRED") — the
  reference doesn't show one.
- Alias hint text reads the real backend rule ("2-24 letters, numbers,
  dots, underscores or hyphens") rather than the reference's inaccurate
  "3-20 characters... `_` only".

## 10. Backend confirmation

No file under `supabase/` was created, modified, or deleted.
