# Player Shell V2 + Pass V2 (pre-event) — Delivery

## Base commit

Built against `origin/main` at the commit that shipped Registration V2
("feat: ship v2 registration flow"). Apply on top of that.

## Files created

```
src/app/games/page.tsx
src/app/players/page.tsx
src/app/more/page.tsx
src/app/pass/PassCountdownScreen.tsx
src/components/brand/v2/icons.tsx
src/components/brand/v2/PlayerAvatar.tsx
src/features/player-shell/PlayerShell.tsx
src/features/player-shell/PlayerShellNav.tsx
src/features/player-shell/PlayerIdentity.tsx
src/features/pass/whatsappOpened.ts
src/features/pass/v2/format.ts
src/features/pass/v2/WhatsAppCta.tsx
src/features/pass/v2/SocialProof.tsx
src/styles/player-shell.css
src/styles/pass-v2.css
supabase/migrations/20260901002000_avatar_and_social_proof.sql
supabase/tests/13_avatar_and_social_proof.test.sql
```

## Files modified (overwrite existing)

```
src/app/pass/PassScreen.tsx      — dead Screen 06 code removed, PASS_COUNTDOWN rewired to Player Shell + Pass V2
src/features/pass/types.ts       — +event.id, +player.registrationId, +player.avatarColor, +socialProof
src/components/ui/Button.tsx     — +poster-quiet variant, +external-link support (target="_blank")
src/styles/tokens.css            — +--avatar-fg-strong (see "Contrast" below)
src/app/globals.css              — import swap (event-pass.css out, player-shell.css + pass-v2.css in)
docs/SCREEN-STATUS.md
```

## Files to delete

```
src/app/pass/EventPassScreen.tsx
src/features/pass/greeting.ts
src/features/pass/countdown.ts
src/features/pass/fresh.ts
src/styles/event-pass.css
```

All confirmed orphaned via repo-wide grep before deletion. `fresh.ts`
(`markPassFresh`/`hasPassFreshFlag`) had zero callers anywhere — Registration
V2 stopped calling it, and this slice's own in-place completion transition
now covers that moment, so it was genuinely dead, not just superseded.

## Migration

`20260901002000_avatar_and_social_proof.sql` (not yet applied to
`origin/main`, so edited in place through three review rounds rather than
stacked as separate migrations):

- `players.avatar_color` — 8-color palette `check` constraint, with a column
  `DEFAULT` (not just an explicit assignment in `register_player()`) so any
  insert path, including existing pgTAP fixtures, is always safe.
- `register_player()` — additive only; diffed against the original function
  text at each round to confirm nothing else changed.
- `get_player_state()` — additive only: `event.id`, `player.registrationId`,
  `player.avatarColor`, and `socialProof` (PASS_COUNTDOWN view only:
  `admittedCount`, `avatars` ≤6, `previewAliases` ≤3 — ordered by
  `player_number`, not `created_at`, which ties within a transaction).

## Final test results

**pgTAP: 274/274 assertions pass, 0 failures** (256 pre-existing + 18 new),
run against real local Postgres via `scripts/local-verify.sh`.

**TypeScript:** clean. **ESLint:** clean. **Production build:** succeeds,
14 routes (`/games`, `/players`, `/more` added; every pre-existing route
unchanged). No `dev-preview-*` route present in the final build — created
for verification, confirmed via `git status` to be fully removed before
packaging.

**Responsive (screenshots included):** 360×740, 390×844, 430×932, 1440×900 —
no horizontal overflow at any size (`scrollWidth` matches viewport at each),
verified via Playwright, not assumed.

**Keyboard/focus:** tab order is CTA → Pass → Games → Players → More;
3px visible focus rings on both the CTA and nav tabs; `aria-current="page"`
present only on the active tab, confirmed via direct DOM inspection.

**WhatsApp CTA states, all verified via real render + localStorage
simulation:** before-first-open (pink), after-first-open (neutral,
`OPEN WHATSAPP GROUP`, still fully interactive — not styled as disabled),
refresh-persistence, and the no-URL pending state (quiet, non-blocking).

## This round's three specific fixes

**1. WhatsApp-opened key now uses real identity.** Changed from
`recess:whatsapp-opened:<eventSlug>:<playerNumber>` to
`recess:whatsapp-opened:<eventId>:<registrationId>`. Both IDs are the raw
UUIDs already selected inside `get_player_state()`'s existing query (`r.id`,
`r.event_id`) — surfacing them was additive, not a new query.

**2. Avatar-initial contrast — a real failure was found, the palette was
not changed.** Computed actual WCAG contrast (real relative-luminance
formula, not assumed) between the standard ink foreground and all 8
palette colors at the initial's real rendered size:

| Color | vs ink | AA (4.5:1) |
|---|---|---|
| #FF3B8D | 5.46 | pass |
| #FF7A2F | 7.04 | pass |
| #F4B940 | 10.34 | pass |
| #2F6BFF | **4.07** | **fail** |
| #7C5CFC | **4.18** | **fail** |
| #27B38A | 6.89 | pass |
| #E95D78 | 5.49 | pass |
| #D94EFF | 5.65 | pass |

Two colors genuinely fail. Checked white as an alternative — it doesn't
clean this up either (4.50 / 4.38, one borderline-pass and one still
failing). Pure black clears both (4.67 / 4.79), and was the only option
tested that does. `PlayerAvatar.tsx` now computes this at runtime from the
actual `color` prop (not a hardcoded per-hex lookup table, so it stays
correct if the palette is ever revised) and falls back to a new token,
`--avatar-fg-strong` (tokens.css), only for colors that need it. **The
8-color palette itself is completely unchanged** — this is a text-color
accommodation for 2 of 8 entries, not a palette edit.

**3. Everything re-validated after both changes** — see "Final test
results" above; nothing regressed.

## Remaining intentional differences from the reference

- Nav icons are genuine hand-traces (slightly rougher edges than a vector
  icon library) — verified at actual 24-28px display size and accepted per
  the brief's own instruction, not silently swapped for a generic icon set.
- Player Shell (bounded canvas + bottom nav) is applied to `PASS_COUNTDOWN`
  only. `WAITLISTED`/`CHECK_IN_OPEN`/`ROOM_ASSIGNED`/`CHECKED_IN_WAITING`/
  the plain fallback keep their pre-existing presentation, unwrapped — a
  deliberate scope decision (see `docs/SCREEN-STATUS.md`), not an oversight.
- Games/Players/More are minimal, unstyled placeholders (`REFERENCE` in
  `docs/SCREEN-STATUS.md`) — they exist only so the new nav has somewhere
  real to link instead of a 404.

## Recommended commit message

```
feat: ship player shell v2 + pass v2 pre-event state
```
