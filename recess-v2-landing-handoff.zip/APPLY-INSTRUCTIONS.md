# V2 Landing — Apply Instructions

## 1. Base commit

This work was built against:

```
7eccd0e8af1d706a7bc567da14335316484cc045
```
("chore: clean pre-v2 test and dead arrival prototype", `origin/main`)

Apply these files on top of that commit. If `main` has moved since, diff
against `7eccd0e` first and re-check for conflicts before applying.

## 2. Created files (copy in as-is)

```
src/app/Landing.tsx
src/styles/landing.css
src/components/brand/v2/RecessWordmark.tsx
src/features/landing/event.ts
src/features/landing/WhatIsRecess.tsx
public/brand/v2/all-work-no-play.svg
public/brand/v2/hero-pawn-die.webp
```

## 3. Modified files (overwrite existing)

```
src/app/page.tsx
src/app/layout.tsx
src/app/globals.css
src/styles/tokens.css
src/components/ui/Button.tsx
src/components/brand/PlayMark.tsx
src/styles/register.css
docs/SCREEN-STATUS.md
```

## 4. Files to delete

```
src/app/ArrivalLanding.tsx
src/styles/arrival.css
public/brand/landing-background.webp
public/brand/arrival-background.webp
```

Confirmed via repo-wide grep before removal: nothing else references any
of these four paths.

## 5. Verification results

- **TypeScript** (`npx tsc --noEmit`): clean, 0 errors.
- **ESLint** (`npx eslint .`): clean, 0 errors/warnings.
- **Next build** (`npm run build`): succeeds. Route list unchanged from
  before this slice (`/` still `ƒ` dynamic, same 11 routes total).
- **Viewport checks** (Playwright, real rendered screenshots, not
  assumption): tested at 360×740 (narrow mobile), 390×844 (primary
  mobile), 430×932 (large mobile), 1440×900 (desktop). At every size, CTA
  and "WHAT IS RECESS?" are fully visible with no scroll needed
  (`scrollHeight` ≤ viewport height at all four; narrow mobile is 742 vs.
  740 — a 2px rounding-level difference, not a visible issue). No
  horizontal overflow at any size (`scrollWidth` === viewport width at
  all four).
- **Keyboard/focus check** (Playwright): Tab order is CTA link → "WHAT IS
  RECESS?" toggle, in that order, matching visual order. Both receive a
  visible 3px amber focus ring at 2px offset (the existing global
  focus-visible token). The disclosure toggle is fully keyboard-operable:
  `Enter` flips `aria-expanded` to `true` and reveals the panel
  (`hidden` becomes `false`).
- **Reduced-motion check**: no new animation was added by this slice. The
  app's existing global `@media (prefers-reduced-motion: reduce)` rule
  (a universal `*` selector zeroing animation/transition durations)
  already covers the new poster button's press transition — verified by
  reading that rule, not by adding anything new for it to cover.
- **Backend**: zero files under `supabase/` were touched (`git status
  supabase/` was empty for this entire slice). No migrations, no RPC
  changes.

## 6. Known unresolved blocker — public event data

There is currently no way for a visitor with **no session at all** to
read real event data (name/date/time/timezone). `get_player_state()`
requires an authenticated session; nothing in the schema exposes a
`SECURITY DEFINER` function granted to `anon` for the safe public subset
of `events` columns a landing page needs.

This is isolated to one function — `getPublicEventInfo()` in
`src/features/landing/event.ts` — which currently returns the same
placeholder values the old page hardcoded. The gap is documented in that
file's own comment. Swapping in real data once a public RPC exists is a
one-function change, not a redesign.

**This needs one of:**
- A new, minimal, read-only `SECURITY DEFINER` RPC granted to `anon`
  (safe fields only: event name, `starts_at`, timezone — nothing else),
  added as a new forward-only migration, **or**
- Explicit direction to solve this a different way.

No migration was written for this — per instruction, database changes
were flagged rather than made speculatively.

## 7. Visual limitations worth knowing about

- Desktop scaling is conservative: the same poster composition scales up
  modestly and stays centered in a capped-width frame, rather than being
  independently re-composed for wide viewports. This was a deliberate
  choice (see report), not an attempted-and-failed fidelity match.
- Fidelity to the reference was verified by direct visual comparison at
  each tested viewport size, not by pixel-coordinate measurement against
  the screenshot beyond the initial composition pass.
- Two real defects were found and fixed during this work, both confirmed
  via rendered screenshots (not assumed): a solid border-line artifact
  baked into the original `hero-pawn-die-composition.webp` upload's right
  edge (cropped out), and a small set of hairline tracing artifacts in
  the vectorized headline/brush asset (removed via morphological
  cleaning before re-tracing). Both were verified gone in the final
  shipped assets.

## 8. Backend confirmation

No file under `supabase/` was created, modified, or deleted at any point
in this slice. `git status supabase/` returns empty. The one backend gap
that exists (§6) was deliberately left as a flagged blocker rather than
addressed with a speculative migration.
