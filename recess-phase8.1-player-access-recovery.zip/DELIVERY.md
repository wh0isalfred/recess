# Phase 8.1 — Player Access & Secure Multi-Device Recovery — Completion Report

## Summary

Production-grade multi-device identity model, a real security vulnerability
found and closed during the required audit, and the `/access` phone-OTP
recovery flow, reusing the exact onboarding visual system. **Full pgTAP
suite: 491/491 pass, 0 failures** (472 pre-existing + 19 new). TypeScript,
ESLint, and production build all clean. Nothing committed or pushed.

## A real vulnerability found during the required audit, not assumed

`register_player()`'s existing `players` upsert unconditionally set
`real_name = excluded.real_name` for *any* phone number submitted —
authenticated recognized session or not. Concretely: before this phase, an
unverified anonymous session that simply typed someone else's real
WhatsApp number into the registration form would silently overwrite that
person's stored name, and would receive back that existing player's
`alias`/`player_number`/`registration_id` in the response. This is exactly
the class of hole the brief describes ("must NOT take over, modify,
register as, or receive access to that player") — found by reading the
actual function, not inferred from the brief's own description of the
risk.

## The identity model

`players.id` is the permanent identity. `player_auth_identities` is the
new many-device mapping (`player_id`, `auth_user_id` unique, `identity_type`
∈ `ANONYMOUS`/`PHONE_VERIFIED`, `verified_at`, `created_at`,
`unique(player_id, auth_user_id)`) — exactly the shape requested.
Backfilled from every existing registration's `auth_user_id` in the same
migration. `event_registrations.auth_user_id` itself is untouched — still
set exactly as before; the new resolution path runs alongside it, not
instead of it structurally.

**Centralized, not scattered**: one function, `current_player_id()`,
resolves "which player does this session belong to." Every function the
brief named — `get_player_state`, `check_in_player`,
`is_authorized_for_room`, and `register_player`'s own guard — now goes
through it instead of comparing `event_registrations.auth_user_id =
auth.uid()` directly. Diffed each modified function against its exact
prior deployed text before considering this done (the discipline this
whole project has used since it first got burned by silent drift), and
restored several documentation comments I'd initially dropped along the
way.

**Keeping `player_auth_identities` in sync is a trigger, not per-caller
logic**: `event_registrations_sync_identity` fires on insert or on any
update of `auth_user_id`, so the invariant holds regardless of which code
path creates or reassigns a registration — `register_player()` today,
anything else later, or (concretely, discovered while testing) the many
existing test fixtures that insert or update `event_registrations` directly
without ever calling `register_player()` at all. This is what let the
entire pre-existing test suite keep working without hand-editing dozens of
fixtures individually.

## register_player()'s fixed logic

Before touching `players` at all, it now resolves both "who does this
phone already belong to" and "who is this session already recognized as."
An unrecognized session claiming an existing phone, or a recognized
session attempting to also claim a second, different phone, is refused
identically (`phone_already_registered` for a first attempt with the
existing phone, `session_already_registered` for a fresh-phone attempt
from an already-linked session) — neither error discloses which specific
case applies, avoiding a phone-registration enumeration oracle. A
genuinely recognized session (a real resubmit, or a device that already
recovered access) proceeds exactly as before, updating only its own
player's `real_name`/consent.

## recover_player_access()

Requires `auth.uid()`; derives the phone strictly from
`auth.users.phone`/`phone_confirmed_at` — the real, server-side,
Supabase-populated verification state, never a client-supplied parameter.
Normalizes Supabase's own no-leading-`+` phone format against RECESS's
`phone_e164` convention. Idempotent (repeated calls from an
already-recognized session change nothing). Never deletes or touches any
other identity row — confirmed directly in tests: both the original device
and a newly recovered device remain independently valid afterward, and
coordinator authorization (`is_authorized_for_room`) works correctly from
either.

## Frontend

- **Landing**: "Already in RECESS? Open your pass →" added between the
  primary CTA and `WHAT IS RECESS?`, shown only when the session isn't
  already recognized (a recognized session already sees `OPEN YOUR PASS`
  as its primary button, per the existing, unchanged
  `resolvePlayerIdentity()` logic — this is what already makes "recognized
  browser → landing opens pass normally" true, not something new).
- **`WHAT IS RECESS?`** already had click-to-expand disclosure behavior
  built in; added a `scrollIntoView` on open only (never on close), which
  is the "move the page up so we can read the content" behavior described.
- **`/access`**: two screens, `RegistrationShell` reused exactly (same
  header, same pink progress bar — `total={2}` instead of 3, same
  typography/fields/artwork treatment/Continue button), light mode only,
  no admin styling, no new success screen — successful verification
  redirects straight to `/pass`.
- **Images**: the two uploaded reference images are the actual artwork —
  saved as `access-whatsapp.webp` (dice, Screen 1) and `access-code.webp`
  (pawn + pass card, Screen 2), distinct filenames from the existing
  `onboarding-*.webp` assets so neither collides with or replaces the real
  registration flow's own artwork.
- **Real Supabase phone OTP**: `signInWithOtp({ phone })` sends the code;
  `verifyOtp({ phone, token, type: "sms" })` is the actual proof of phone
  ownership — nothing custom, nothing RECESS invents. `recover_player_access()`
  only runs after that verification succeeds.
- **OTP UX**: resend cooldown (30s, client-side display only — no invented
  throttling beyond disabling the button while a send is in flight;
  Supabase/the provider's own rate limiting is the real backstop), disabled
  duplicate submission (verify state gates re-entry), wrong/expired code
  handled with distinct copy, network failure surfaces a generic retry-safe
  message, auto-advance between OTP cells with backspace-to-previous, and
  the code is held only in component state — never logged, never persisted.

## What I could not build or verify, stated plainly

**No Supabase phone/SMS provider configuration exists in this sandbox, and
I have no way to create or verify one.** I did not fake this. What's built
is the complete, real client-side and server-side code path
(`signInWithOtp`/`verifyOtp`/`recover_player_access()`) — it will not
actually send an SMS until your Supabase project has a phone provider
(Twilio, MessageBird, or Vonage, configured under Authentication → Providers
→ Phone in the Supabase dashboard) enabled and configured with real
credentials. This is external configuration only you can complete; nothing
in this codebase can substitute for it.

## Tests added

`supabase/tests/23_player_access_recovery.test.sql` — 19 assertions:
anonymous first-time registration still works; an unrecognized session
cannot claim an existing phone (and neither the player's stored name nor
its registration count changes as a result); the same session can still
register normally with a genuinely unclaimed phone (the block is scoped,
not a blanket ban); a session with no verified phone cannot recover
anything; a genuinely verified phone matching no player is refused; a
genuinely verified matching phone recovers successfully and idempotently;
two independent device identities exist afterward and both the original
and newly recovered device resolve to the correct player; a legitimately
recognized device can still re-submit registration; coordinator
authorization works from both devices and is still correctly refused for
an unrelated session; and direct RPC calls fail the same way a UI-mediated
attempt would.

`supabase/tests/13_avatar_and_social_proof.test.sql` was also updated —
two of its existing scenarios had, without realizing it, been testing
exactly the lax behavior this phase closes (a *different*, unrecognized
session silently reusing an existing phone was being treated as a normal
idempotent retry). Fixed to reflect the correct model: a genuine retry
reuses the same recognized session, and a fresh session recovers access
first (simulating what `recover_player_access()` does after real
verification) before it can register-again for a second event.

## Full pgTAP result

**491/491 assertions pass, 0 failures** (472 pre-existing + 19 new), run
against real local Postgres, iterated through several real fixture issues
before reaching this state — including one local-test-infrastructure gap
(the mock `auth.users` shim was missing `phone`/`phone_confirmed_at`
entirely, since real Supabase Auth already has these and nothing in
RECESS's own migrations had ever needed them before this phase).

## TypeScript / ESLint / production build

All clean. `/access` appears correctly as a new route in the build output.

## Files created

```
supabase/migrations/20260901003000_player_access_recovery.sql
supabase/tests/23_player_access_recovery.test.sql
src/app/access/page.tsx
src/app/access/AccessView.tsx
src/features/access/actions.ts
public/brand/v2/access-whatsapp.webp
public/brand/v2/access-code.webp
```

## Files modified

```
src/app/Landing.tsx
src/features/landing/WhatIsRecess.tsx
src/styles/landing.css
src/styles/register.css
supabase/tests/13_avatar_and_social_proof.test.sql
scripts/harness/00_supabase_shim.sql   (local no-Docker test harness only — added phone/phone_confirmed_at to the mock auth.users so `scripts/local-verify.sh` can test this phase; real Supabase Auth already has these columns natively)
```

## Files deleted

None.

## Deviations from the brief

None. Did not redesign scoring, coordinator, or player-live systems.

## Unresolved risks / decisions

- **SMS provider configuration**, as stated above — the one thing outside
  this codebase's reach entirely.
- `session_already_registered` vs `phone_already_registered` are two
  distinct error codes for two distinct refusal reasons (a fresh session
  claiming someone else's phone, vs. an already-linked session trying to
  also claim a second phone) — both map to the same generic-enough
  frontend copy on the registration form today, since the existing
  registration UI wasn't asked to distinguish them further in this phase.
- The `/access` flow's own error copy is deliberately generic (avoiding a
  phone-registered enumeration oracle) — if product wants more specific
  guidance later (e.g., "this number isn't registered — did you mean to
  sign up?"), that's a UX decision, not a security one, worth making
  explicitly rather than inferring.

## Explicit confirmations

- **Was a custom OTP system built? NO** — Supabase's own
  `signInWithOtp`/`verifyOtp` throughout.
- **Was service-role code used in any player-facing action? NO.**
- **Was raw Postgres/Supabase error text ever returned to the client? NO**
  — every RPC error is mapped through a friendly-message table.
- **Was any secret exposed? NO.**
- **Was anything committed or pushed? NO.**
- **Was a fake/simulated "successful" SMS implementation presented as
  working? NO** — see the external-configuration section above.

Stopping here as instructed.
